import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String);
    def artifactId = message.getProperty("Id");
    def packageId = message.getProperty("packageId");
    def responseCode = message.getHeader("CamelHttpResponseCode", Integer);
    def responseText = message.getHeader("CamelHttpResponseText", String);
    
    def errorMessages = message.getProperty("ErrorMessage") as List<String>;

    def response = [
        packageId: packageId,
        artifactId: artifactId,
        status: responseCode,
        message: responseText
    ];
    errorMessages << response;
    
    message.setBody(JsonOutput.toJson(errorMessages));
    message.setProperty("ErrorMessage", errorMessages);
    
    return message;
}
