import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve the message body as a byte array and convert it to a UTF-8 string
    def byteArray = message.getBody(byte[])
    def xmlResponse = new String(byteArray, "UTF-8")
    
    // Remove non-ASCII characters from the XML response
    xmlResponse = xmlResponse.replaceAll("[^\\x00-\\x7F]", "")
    
    def parsedXml = new XmlSlurper().parseText(xmlResponse)
    
    def idList = []
    
    // Traverse the parsed XML, finding all nodes named 'Id', and extract their text values
    parsedXml.'**'.findAll { it.name() == 'Id' }.each { idNode ->
        idList << idNode.text()
    }
    
    // Transform the list of 'Id' values into a list of maps with key 'Id'
    def artifactsList = idList.collect { id -> [Id: id] }
    def jsonOutput = [Artifacts: artifactsList]
    
    def jsonString = JsonOutput.toJson(jsonOutput)
    
    jsonString = JsonOutput.prettyPrint(jsonString)
    
    message.setBody(jsonString)
    message.setProperty("ListOfArtifacts", jsonString)
    
    return message
}

