import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve the name of the resource from the message properties
    def fileName = message.getProperty("nameOfResource") as String

    // Define a map of file extensions to resource types
    def resourceTypeMap = [
        "groovy": "groovy",
        "js"    : "js",
        "mmap"  : "mmap"
    ]

    // Extract the file extension and determine the resource type
    def fileExtension = fileName.tokenize('.').last()?.toLowerCase()
    def resourceType = resourceTypeMap.get(fileExtension, "unknown")

    message.setProperty("ResourceType", resourceType)
    
    return message
}
