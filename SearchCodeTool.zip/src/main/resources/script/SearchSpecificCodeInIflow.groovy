import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve the compressed zip file content from the message body as byte array
    byte[] zipBytes = message.getBody(byte[])
    
    message.setProperty("zipFileContent", zipBytes)
    
    def zipInputStream = new ZipInputStream(new ByteArrayInputStream(zipBytes))
    
    def cumulativeArtifacts = message.getProperty("cumulativeArtifacts")
    def artifactId = message.getProperty("Id")
    
    // Retrieve the keyword to search and convert to lowercase, trim whitespace
    def keyword = message.getProperty("codeToSearch")?.toLowerCase()?.replaceAll("\\s+", " ")?.trim()
    
    // Process each file in the zip
    ZipEntry entry
    while ((entry = zipInputStream.nextEntry) != null) {
        if (!entry.isDirectory() && artifactId != "SearchCodeTool") {
            def fileContent = readEntryContent(zipInputStream)
            
            // convert to lowercase, trim whitespace in the file content and check for the keyword
            def normalizedBodyContent = fileContent?.toLowerCase()?.replaceAll("\\s+", " ")?.trim()
            
            if (normalizedBodyContent?.contains(keyword)) {
                cumulativeArtifacts << artifactId
            }
        }
        zipInputStream.closeEntry()
    }
    
    zipInputStream.close()
    

    message.setBody(zipBytes)
    message.setProperty("cumulativeArtifacts", cumulativeArtifacts)
    
    return message
}

// function to read the content of a zip entry
def String readEntryContent(ZipInputStream zipInputStream) {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
    byte[] buffer = new byte[1024]
    int length
    while ((length = zipInputStream.read(buffer)) != -1) {
        outputStream.write(buffer, 0, length)
    }
    return new String(outputStream.toByteArray(), StandardCharsets.UTF_8)
}
