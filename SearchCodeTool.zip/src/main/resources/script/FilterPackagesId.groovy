import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Extract the message body as a byte array
    def byteArray = message.getBody(byte[])
    def xmlResponse = new String(byteArray, "UTF-8")
    
    // Remove non-ASCII characters from the XML response
    xmlResponse = xmlResponse.replaceAll("[^\\x00-\\x7F]", "")
    
    def parsedXml = new XmlSlurper().parseText(xmlResponse)
    
    def packageIdsList = []
    // Traverse the XML to find all nodes named 'Id'
    parsedXml.'**'.findAll { it.name() == 'Id' }.each { IdNode -> 
        def packageId = IdNode.text()
        
        def excludeKeywords = ["test"]

        if (!excludeKeywords.any { packageId.toLowerCase().contains(it.toLowerCase()) }) {
            packageIdsList << packageId
        }

    }
    
    // Transform the list of packageIds into a map structure for JSON output
    def nameList = packageIdsList.collect { packageId -> [packageId: packageId] }
    def jsonOutput = [PackagesId: nameList]
    
    def jsonString = JsonOutput.toJson(jsonOutput)
    
    jsonString = JsonOutput.prettyPrint(jsonString)
    
    message.setBody(jsonString)

    return message
}
