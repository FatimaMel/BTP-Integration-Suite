import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    
    def cumulativeArtifacts = message.getProperty("cumulativeArtifacts")
    def errorMessage = message.getProperty("ErrorMessage")

    def messageLog = messageLogFactory.getMessageLog(message)
    
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Result of search code", "cumulativeArtifacts: ${cumulativeArtifacts}", "text/plain")
        messageLog.addAttachmentAsString("Errors", "Error Messages: ${errorMessage}", "text/plain")
    }

    return message;
}