import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve the body of the incoming message as a string
    def bodyContent = message.getBody(String)
    def keywordFound = false

    // Retrieve the keyword to search from a property, convert to lowercase
    def keyword = message.getProperty("codeToSearch")?.toLowerCase()?.replaceAll("\\s+", " ")?.trim()
    def cumulativeArtifacts = message.getProperty("cumulativeArtifacts")
    def nameOfResource = message.getProperty("nameOfResource")
    def artifactId = message.getProperty("Id")
    def normalizedBodyContent = bodyContent?.toLowerCase()?.replaceAll("\\s+", " ")?.trim()

    keywordFound = normalizedBodyContent?.contains(keyword)

    if (keywordFound && artifactId != "SearchCodeTool") {
        cumulativeArtifacts << artifactId
    }

    message.setBody(cumulativeArtifacts)
    message.setProperty("cumulativeArtifacts", cumulativeArtifacts)

    return message
}
