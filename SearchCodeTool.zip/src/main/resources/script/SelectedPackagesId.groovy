import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput

def Message processData(Message message) {

    def packagesId = message.getProperty("choosePackagesId")
    
    // Split using "||" as the delimiter
    def packageList = packagesId.split("\\|\\|").collect { it.trim() }
    
    // Transform the list into a JSON structure
    def transformedList = packageList.collect { packageValue -> [packageId: packageValue] }
    def jsonOutput = [PackagesId: transformedList]
    
    // Convert the structure to a JSON string
    def jsonString = JsonOutput.toJson(jsonOutput)
    jsonString = JsonOutput.prettyPrint(jsonString)

    message.setBody(jsonString)
    
    return message

}