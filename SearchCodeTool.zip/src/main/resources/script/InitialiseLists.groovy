import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Initialize the properties
    if (message.getProperty("cumulativeArtifacts") == null || message.getProperty("listOfScript") == null) {
        message.setProperty("cumulativeArtifacts", new HashSet<>())
        message.setProperty("listOfScriptWithCollectionName", [:])
        message.setProperty("ErrorMessage", []);
    }
    
    return message
}
