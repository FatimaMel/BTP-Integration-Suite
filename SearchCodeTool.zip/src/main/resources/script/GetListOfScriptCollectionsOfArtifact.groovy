import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Get the ZIP file content as a byte array from the message body
    byte[] zipBytes = message.getBody(byte[])
    def zipInputStream = new ZipInputStream(new ByteArrayInputStream(zipBytes))

    def listOfScript = new HashSet()
    def listOfFileName = new HashSet()
    
    // keyword to search for in the file content, to get script collection name
    def keyword = "<key>scriptBundleId</key>"

    ZipEntry entry
    while ((entry = zipInputStream.nextEntry) != null) {
        if (!entry.isDirectory()) {
            def fileContent = readEntryContent(zipInputStream)
            
            def matcher = fileContent =~ /\b([a-zA-Z0-9_]+)\.(groovy|js)\b/
            matcher.each { match ->
                listOfFileName << match[0]
            }

            if (fileContent.contains(keyword)) {
                // Extract all scriptBundleId values from the file content
                def scriptBundleIdValues = extractAllScriptBundleIdValues(fileContent)
                
                scriptBundleIdValues.each { scriptBundleIdValue ->
                    if (scriptBundleIdValue && !listOfScript.contains(scriptBundleIdValue)) {
                        // Add the scriptBundleId value to the list
                        listOfScript << scriptBundleIdValue
                    }
                }
            }
        }
        zipInputStream.closeEntry()
    }

    zipInputStream.close()

    // Create a JSON object with the collected scriptBundleId values
    def jsonOutput = [
        scriptCollections: listOfScript.collect { [id: it] }
    ]
    
    message.setBody(JsonOutput.toJson(jsonOutput))
    message.setProperty("listOfScript", listOfScript)
    message.setProperty("listOfFileName", listOfFileName)

    return message
}

// Function to read the content of the current ZIP entry
def String readEntryContent(ZipInputStream zipInputStream) {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
    byte[] buffer = new byte[1024]
    int length
    while ((length = zipInputStream.read(buffer)) != -1) {
        outputStream.write(buffer, 0, length)
    }
    return new String(outputStream.toByteArray(), StandardCharsets.UTF_8)
}

// Extracts all scriptBundleId values from the file content
def List<String> extractAllScriptBundleIdValues(String fileContent) {
    def matcher = fileContent =~ /<key>scriptBundleId<\/key>\s*<value>(.*?)<\/value>/
    def scriptBundleIdValues = []
    while (matcher.find()) {
        scriptBundleIdValues << matcher.group(1)
    }
    return scriptBundleIdValues
}
