import com.sap.gateway.ip.core.customdev.util.Message
import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.io.ByteArrayInputStream
import groovy.json.JsonOutput

def Message processData(Message message) {
    byte[] zipBytes = message.getProperty("zipFileContent")
    def zipInputStream = new ZipInputStream(new ByteArrayInputStream(zipBytes))

    def resourceNameList = new HashSet()
    def allowedExtensions = ['groovy', 'js', 'mmap']
    def cumulativeArtifacts = message.getProperty("cumulativeArtifacts")
    def artifactId = message.getProperty("Id")

    ZipEntry entry
    while ((entry = zipInputStream.nextEntry) != null) {
        if (!entry.isDirectory()) {
            // Extract the file name from the entry
            def resourceName = entry.getName().substring(entry.getName().lastIndexOf('/') + 1)
            def fileExtension = resourceName.tokenize('.').last()?.toLowerCase()

            // Check if the file extension is allowed
            if (allowedExtensions.contains(fileExtension)) {
                resourceNameList << resourceName
            }
        }
        zipInputStream.closeEntry()
    }

    zipInputStream.close()

    // Transform the list of resource names into a map structure for JSON output
    def jsonOutput = [
        Resources: resourceNameList.collect { name -> [NameOfResource: name] }
    ]

    def jsonString = JsonOutput.toJson(jsonOutput)
    jsonString = JsonOutput.prettyPrint(jsonString)

    message.setBody(jsonString)

    return message
}
