import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve the ZIP file data as a byte array from the message body
    byte[] zipBytes = message.getBody(byte[])
    def zipInputStream = new ZipInputStream(new ByteArrayInputStream(zipBytes))
    
    def listOfScriptWithCollectionName = message.getProperty("listOfScriptWithCollectionName") as Map
    def cumulativeArtifacts = message.getProperty("cumulativeArtifacts")
    def keyword = message.getProperty("codeToSearch")?.toLowerCase()?.replaceAll("\\s+", " ")?.trim()
    def scriptId = message.getProperty("scriptId")
    def listOfFileName = message.getProperty("listOfFileName")
    def currentArtifactId = message.getProperty("Id")
    
    ZipEntry entry
    while ((entry = zipInputStream.nextEntry) != null) {
        if (!entry.isDirectory()) {
            def fileContent = readEntryContent(zipInputStream)
            def normalizedBodyContent = fileContent?.toLowerCase()?.replaceAll("\\s+", " ")?.trim()
            
            // Check if the file content contains the keyword
            if (normalizedBodyContent?.contains(keyword)) {
                def fileName = entry.getName().substring(entry.getName().lastIndexOf("/") + 1)
                def fileWithPackage = "${fileName} (Package: ${scriptId})"
                
                def normalizedFileWithPackage = fileWithPackage.trim()
                
                // Add the file name and associated artifact ID to the map
                if (listOfFileName.contains(fileName)){
                    if (!listOfScriptWithCollectionName.containsKey(normalizedFileWithPackage)) {
                        listOfScriptWithCollectionName[normalizedFileWithPackage] = new HashSet<String>()
                    }
                    listOfScriptWithCollectionName[normalizedFileWithPackage].add(currentArtifactId)
                }
            }
        }
        zipInputStream.closeEntry()
    }
    
    zipInputStream.close()
    
    listOfScriptWithCollectionName.each { key, value ->
        def found = false
        cumulativeArtifacts.each { artifact ->
            if (artifact instanceof Map && artifact.containsKey(key)) {
                artifact[key].addAll(value)
                found = true
            }
        }
        if (!found) {
            cumulativeArtifacts.add([(key): value])
        }
    }
    
    message.setBody(cumulativeArtifacts)
    message.setProperty("cumulativeArtifacts", cumulativeArtifacts)
    message.setProperty("listOfScriptWithCollectionName", listOfScriptWithCollectionName)
    
    return message
}

// function to read the content of a ZIP entry
def String readEntryContent(ZipInputStream zipInputStream) {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
    byte[] buffer = new byte[1024]
    int length
    while ((length = zipInputStream.read(buffer)) != -1) {
        outputStream.write(buffer, 0, length)
    }
    return new String(outputStream.toByteArray(), StandardCharsets.UTF_8)
}